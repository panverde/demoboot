package com.joaquin.repository;

import com.joaquin.model.StudentParent;
import com.joaquin.model.StudentParentPk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface IStudentParentsRepository extends JpaRepository<StudentParent, StudentParentPk> {

    List<StudentParent> findAllByPrimaryKeyStudentIdStudentId (Integer id);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM student_parents f WHERE f.student_id =?1",nativeQuery = true)
    void deleteStudentParentByIdStudent(Integer id);


}
