package com.joaquin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.joaquin.model.Parents;

public interface IParentsRepository extends JpaRepository<Parents, Integer> {

}
