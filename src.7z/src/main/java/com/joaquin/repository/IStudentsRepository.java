package com.joaquin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.joaquin.model.Students;

public interface IStudentsRepository extends JpaRepository<Students, Integer>{

}
