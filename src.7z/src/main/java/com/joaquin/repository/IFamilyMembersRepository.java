package com.joaquin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.joaquin.model.FamilyMembers;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface IFamilyMembersRepository extends JpaRepository<FamilyMembers, Integer> {

    @Modifying
    @Transactional
    @Query(value = "delete from family_members fm where fm.family_id = ?1", nativeQuery = true)
    void deleteFamilyMembersByIdFamilies(Integer id);

    @Modifying
    @Transactional
    @Query(value = "delete from family_members fm where fm.parent_id = ?1", nativeQuery = true)
    void deleteFamilyMembersByIdParents(Integer id);

    @Modifying
    @Transactional
    @Query(value = "delete from family_members fm where fm.student_id = ?1", nativeQuery = true)
    void deleteFamilyMembersByIdStudents(Integer id);

    //@Query(value = "DELETE FROM families f WHERE f.head_of_family_parent =?1",nativeQuery = true)
}
