package com.joaquin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "family_members")
public class FamilyMembers {
	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer familyMemberId;

	@ManyToOne()
	@JoinColumn(name = "family_id")
	private Families familyId;

	@Column(length = 30, name = "parent_or_student_member")
	private String parentOrStudentMember;

	@ManyToOne()
	@JoinColumn(name = "parent_id")
	private Parents parentId;

	@JsonIgnoreProperties("ltaStudentParents")
	@ManyToOne()
	@JoinColumn(name = "student_id")
	private Students studentId;



}
