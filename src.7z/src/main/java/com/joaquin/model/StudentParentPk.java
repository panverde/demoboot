package com.joaquin.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

@Data
@Embeddable
public class StudentParentPk implements Serializable {

  @ManyToOne
  @JoinColumn(name = "student_id")
  private Students studentId;

  @ManyToOne
  @JoinColumn(name = "parent_id")
  private Parents parentId;


}
