package com.joaquin.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joaquin.model.Families;
import com.joaquin.service.impl.FamiliesServiceImpl;

@RestController
@RequestMapping("/families")
public class FamiliesController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private FamiliesServiceImpl familiesService;
	
	@GetMapping(value = "/all")
	public ResponseEntity<List<Families>> listAllFamilies(){	
		return new ResponseEntity<List<Families>>(familiesService.findAll(), HttpStatus.OK);
	}
	
	@PostMapping(value="/nuevo")
	public @ResponseBody ResponseEntity<Void> create(@RequestBody Families families) throws URISyntaxException {
	 try {
	  // guardar en base de datos
		 Families newFamilies = familiesService.create(families);
	  return ResponseEntity.created(new URI("/nuevo/"+newFamilies.getFamilyId())).build();
	 } catch (Exception e) {
	  // Excepcion retorna error (409)
	  return ResponseEntity.status(HttpStatus.CONFLICT).build();
	 }
	}	
	
	@PutMapping(path="/update/{familiesId}")
	public ResponseEntity<Void> updateExist(@RequestBody Families families,@PathVariable Integer familiesId)  {
	 try {
	  families.setFamilyId(familiesId);
	  familiesService.update(families,familiesId);
	  return ResponseEntity.noContent().build();
	 } catch (Exception e) {
	  return ResponseEntity.notFound().build();
	 }
	}
	
	@DeleteMapping("/delete/{familiesId}")
	public ResponseEntity<Void> deleteParents(@PathVariable("familiesId") Integer id) {
		logger.info("> delete [persona]");
		try {
			familiesService.delete(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}	
	}

}
