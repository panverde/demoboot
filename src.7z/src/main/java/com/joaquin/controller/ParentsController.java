package com.joaquin.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joaquin.model.Parents;
import com.joaquin.service.impl.ParentsServiceImpl;

@RestController
@RequestMapping("/parents")
public class ParentsController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ParentsServiceImpl parentsService;
	
	@GetMapping(value = "/all")
	public ResponseEntity<List<Parents>> listAllParents(){	
		return new ResponseEntity<List<Parents>>(parentsService.findAll(), HttpStatus.OK);
	}
	
	@PostMapping(value="/nuevo")
	public @ResponseBody ResponseEntity<Void> create(@RequestBody Parents parents) throws URISyntaxException {
	 try {
	  // guardar en base de datos
	  Parents newParents = parentsService.create(parents);
	  return ResponseEntity.created(new URI("/nuevo/"+newParents.getParentId())).build();
	 } catch (Exception e) {
	  // Excepcion retorna error (409)
	  return ResponseEntity.status(HttpStatus.CONFLICT).build();
	 }
	}	
	
	@PutMapping(path="/update/{parentsId}")
	public ResponseEntity<Void> updateExist(@RequestBody Parents parents,@PathVariable Integer parentsId)  {
	 try {
	  parents.setParentId(parentsId);
	  parentsService.update(parents,parentsId);
	  return ResponseEntity.noContent().build();
	 } catch (Exception e) {
	  return ResponseEntity.notFound().build();
	 }
	}
	
	@DeleteMapping("/delete/{parentsId}")
	public ResponseEntity<Void> deleteParents(@PathVariable("parentsId") Integer id) {
		logger.info("> delete [persona]");
		try {
			parentsService.delete(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}	
	}

}
