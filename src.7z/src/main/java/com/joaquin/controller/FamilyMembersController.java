package com.joaquin.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joaquin.model.FamilyMembers;
import com.joaquin.service.impl.FamilyMembersServiceImpl;

@RestController
@RequestMapping("/familymembers")
public class FamilyMembersController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private FamilyMembersServiceImpl familyMembersService;
	
	@GetMapping(value = "/all")
	public ResponseEntity<List<FamilyMembers>> listAllFamilyMembers(){	
		return new ResponseEntity<List<FamilyMembers>>(familyMembersService.findAll(), HttpStatus.OK);
	}
	
	@PostMapping(value="/nuevo")
	public @ResponseBody ResponseEntity<Void> create(@RequestBody FamilyMembers familyMembers) throws URISyntaxException {
	 try {
	  // guardar en base de datos
		 FamilyMembers newFamilyMembers = familyMembersService.create(familyMembers);
	  return ResponseEntity.created(new URI("/nuevo/"+newFamilyMembers.getFamilyMemberId())).build();
	 } catch (Exception e) {
	  // Excepcion retorna error (409)
	  return ResponseEntity.status(HttpStatus.CONFLICT).build();
	 }
	}	
	
	@PutMapping(path="/update/{familyMembersId}")
	public ResponseEntity<Void> updateExist(@RequestBody FamilyMembers familyMembers,@PathVariable Integer familyMembersId)  {
	 try {
	  familyMembers.setFamilyMemberId(familyMembersId);
	  familyMembersService.update(familyMembers,familyMembersId);
	  return ResponseEntity.noContent().build();
	 } catch (Exception e) {
	  return ResponseEntity.notFound().build();
	 }
	}
	
	@DeleteMapping("/delete/{familyMembersId}")
	public ResponseEntity<Void> deleteFamilyMembers(@PathVariable("familyMembersId") Integer id) {
		logger.info("> delete [persona]");
		try {
			familyMembersService.delete(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}	
	}

}
