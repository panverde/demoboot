package com.joaquin.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import com.joaquin.dto.request.CreateStudentRequest;
import com.joaquin.dto.request.UpdateStudentsRequest;
import com.joaquin.dto.response.ListStudentsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joaquin.model.Students;
import com.joaquin.service.impl.StudentsServiceImpl;

@RestController
@RequestMapping("/students")
public class StudentsController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private StudentsServiceImpl studentService;


	@GetMapping(value = "/all")
	public ResponseEntity<List<ListStudentsResponse>> listAllStudents(){
		return new ResponseEntity<List<ListStudentsResponse>>(studentService.findAlls(), HttpStatus.OK);
	}
	

	@PostMapping(value="/nuevo")
	public @ResponseBody ResponseEntity<Void> create(@RequestBody Students students) throws URISyntaxException {
	 try {
	  // guardar en base de datos
	  Students newStudents = studentService.create(students);
	  return ResponseEntity.created(new URI("/nuevo/"+newStudents.getStudentId())).build();
	 } catch (Exception e) {
	  // Excepcion retorna error (409)
	  return ResponseEntity.status(HttpStatus.CONFLICT).build();
	 }
	}

	@PostMapping(value="/new")
	public @ResponseBody
	void createStudent(@RequestBody CreateStudentRequest students) throws URISyntaxException {

			 studentService.createStudent(students);

	}

	@PutMapping(path="/update/{studentsId}")
	public ResponseEntity<Void> updateExist(@RequestBody Students students,@PathVariable Integer studentsId)  {
	 try {
	  students.setStudentId(studentsId);
	  studentService.update(students,studentsId);
	  return ResponseEntity.noContent().build();
	 } catch (Exception e) {
	  return ResponseEntity.notFound().build();
	 }
	}

	@PutMapping(path = "/{studentsId}")
	public ResponseEntity<Void> updateExistStudent(@RequestBody UpdateStudentsRequest students, @PathVariable Integer studentsId)  {
		try {
			students.setStudentId(studentsId);
			studentService.updateStudent(studentsId,students);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}
	}
	
	@DeleteMapping("/delete/{studentsId}")
	public ResponseEntity<Void> deleteStudents(@PathVariable("studentsId") Integer id) {
		logger.info("> delete [persona]");
		try {
			studentService.delete(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}	
	}
	
}
