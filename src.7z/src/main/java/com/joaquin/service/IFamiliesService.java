package com.joaquin.service;

import com.joaquin.model.Families;

public interface IFamiliesService extends CRUD<Families>{

}
