package com.joaquin.service;

import com.joaquin.model.FamilyMembers;

public interface IFamilyMembersService extends CRUD<FamilyMembers>{

}
