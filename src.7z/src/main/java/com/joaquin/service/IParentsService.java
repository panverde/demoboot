package com.joaquin.service;

import com.joaquin.model.Parents;

public interface IParentsService extends CRUD<Parents> {

}
