package com.joaquin.service;

import com.joaquin.dto.request.CreateStudentRequest;
import com.joaquin.dto.request.UpdateStudentsRequest;
import com.joaquin.dto.response.ListStudentsResponse;
import com.joaquin.model.Students;

import java.util.List;

public interface IStudentsService extends CRUD<Students>{

    List<ListStudentsResponse> findAlls();

    void updateStudent(Integer id, UpdateStudentsRequest obj);

    void createStudent(CreateStudentRequest obj);

	
}
