package com.joaquin.service.impl;

import java.util.List;
import java.util.Optional;

import com.joaquin.model.Students;
import com.joaquin.repository.IFamiliesRepository;
import com.joaquin.repository.IFamilyMembersRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.joaquin.model.Parents;
import com.joaquin.repository.IParentsRepository;
import com.joaquin.service.IParentsService;

@Service
public class ParentsServiceImpl implements IParentsService{

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IParentsRepository repositoryParents;
	@Autowired
	private IFamiliesRepository repositoryFamilies;
	@Autowired
	private IFamilyMembersRepository repositoryFamilyMembers;
	
	@Override
	public List<Parents> findAll() {
		
		return repositoryParents.findAll();	
	}

	@Override
	public Parents create(Parents obj) {
		// TODO Auto-generated method stub
		return repositoryParents.save(obj);
	}

	@Override
	public Parents find(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Parents obj,Integer id) {
		// TODO Auto-generated method stub
		 repositoryParents.save(obj);
	}

	@Override
	public void delete(Integer id) {

		Optional<Parents> parentsOptional = repositoryParents.findById(id);

		if (parentsOptional.isPresent()){

		repositoryFamilyMembers.deleteFamilyMembersByIdParents(id);
		repositoryFamilies.deleteFamilyByIdParent(id);
		repositoryParents.deleteById(id);

			logger.info("delete parent");

		}else {
			logger.error("Not found parent id");
		}
		
	}

}
